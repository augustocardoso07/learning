import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;

public class Solver {

    private int moves;
    private boolean isSolvable;
    private Stack<Board> path = new Stack<Board>();

    private class Node implements Comparable<Node> {
        private int priority;
        private Board board;
        private Node previus;

        public Node(Board b, int moves, Node previus) {
            this.board = b;
            this.priority = b.manhattan() + moves;
            this.previus = previus;
        }

        public boolean isGoal() {
            return this.board.isGoal();
        }

        public Node getPrevius() {
            return this.previus;
        }

        public Board getBoard() {
            return this.board;
        }

        public int compareTo(Node that) {
            if (this.priority < that.priority) return -1;
            if (this.priority > that.priority) return  1;
            if (this.board.hamming() < that.board.hamming()) return -1;
            if (this.board.hamming() > that.board.hamming()) return  1;
            return 0;
        }

    }

    public Solver(Board initial) {
        Node init = new Node(initial, 0, null);
        Node twin  = new Node(initial.twin(), 0, null);

        MinPQ<Node> pq1 = new MinPQ<Node>();
        MinPQ<Node> pq2 = new MinPQ<Node>();

        Board critical = initial;
        Board twincrit = initial.twin();

        for (int move = 0; move < 1115000; move++) {
            if (init.isGoal()) {
                isSolvable = true;
                break;
            }
            if (twin.isGoal()) {
                isSolvable = false;
                break;
            }

            for (Board neib: init.getBoard().neighbors()) {
                if (critical.equals(neib)) continue;
                pq1.insert(new Node(neib, move, init));
            }

            critical = init.getBoard();
            init = pq1.delMin();

            for (Board neib: twin.getBoard().neighbors()) {
                if (twincrit.equals(neib)) continue;
                pq2.insert(new Node(neib, move, twin));
            }

            twincrit = init.getBoard();
            twin = pq2.delMin();

            //System.out.println("iter = " + move);
        }



        moves = -1;
        if (isSolvable()) {
            while (init != null) {
                path.push(init.getBoard());
                init = init.getPrevius();
                moves++;
            }
        }

    }

    public boolean isSolvable() {
        return isSolvable;
    }

    public int moves() {
        return moves;
    }

    public Iterable<Board> solution() {
        if (!isSolvable()) return null;
        return path;
    }
    public static void main(String[] args) {
        // create initial board from file
        
        In in = new In(args[0]);
        int N = in.readInt();
        int[][] blocks = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
        StdOut.println("Moves =>> " + solver.moves());
        

        /*
        int[][] blocks = {
                            {1, 2},
                            {3, 0}
        };

        Board b  = new Board(blocks);
        Solver s = new Solver(b);
        StdOut.println("1: true  = " + s.isSolvable());
        StdOut.println("2: 0     = " + s.moves());

        int[][] blocks2 = {
                            {2, 1},
                            {3, 0}
        };

        for (Board p : s.solution()) {
            StdOut.println(p);
        }

        b = new Board(blocks2);
        s = new Solver(b);
        StdOut.println("3: false  = " + s.isSolvable());
        StdOut.println("4: -1     = " + s.moves());

        StdOut.println("-------------------------------");

        int[][] blocks3 = {
                            {1, 2},
                            {0, 3}
        };

        b = new Board(blocks3);
        s = new Solver(b);
        StdOut.println("5: true  = " + s.isSolvable());
        StdOut.println("6: 1     = " + s.moves());

        StdOut.println("Solution:");
        for (Board p : s.solution()) {
            StdOut.println(p);
        }
        */

    }
}