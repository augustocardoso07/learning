import java.util.ArrayList;

public class Board {

    private int[][] mBlocks;
    private final int mN;
    private int manhattan;

    public Board(int[][] blocks) {
        mN = blocks.length;
        mBlocks = copy2dArray(blocks);
        manhattan = man();
    }

    private int[][] copy2dArray(int[][] a) {
        int[][] copy = new int[mN][mN];
        for (int i = 0; i < mN; i++) {
            for (int j = 0; j < mN; j++) {
                copy[i][j] = a[i][j];
            }
        }
        return copy;
    }

    public int dimension() { return mN; }

    public int hamming() {
        int result = 0;
        int count = 1;
        for (int[] line : mBlocks) {
            for (int tile : line) {
                if (!(tile == count++) && (tile != 0)) result++;
            }
        }
        return result;
    }

    public int manhattan() {
        return this.manhattan;
    }

    private int man() {
        int result = 0;
        for (int i = 0; i < mN; i++) {
            for (int j = 0; j < mN; j++) {
                int tile = mBlocks[i][j];
                if (tile != 0) {
                    result += distanceToGoal(tile, i, j);
                }
            }
        }
        return result;
    }

    private int distanceToGoal(int tile, int i, int j) {
        int iGoal = (tile - 1) / mN;
        int jGoal = (tile - 1) % mN;
        return Math.abs(i - iGoal) + Math.abs(j - jGoal);
    }

    public boolean isGoal() {
        return this.manhattan == 0;
    }

    public Board twin() {
        if (mN <= 1) throw new IllegalArgumentException("size 1 board don't have twin");
        int[][] twinBolocks = copy2dArray(mBlocks);
        if (zeroInFirstTwo()) {
            swap(1, 0, 1, 1, twinBolocks);
        } else {
            swap(0, 0, 0, 1, twinBolocks);
        }
        return new Board(twinBolocks);
    }

    private void swap(int iFrom, int jFrom, int iTo, int jTo, int[][] a) {
        int temp = a[iFrom][jFrom];
        a[iFrom][jFrom] = a[iTo][jTo];
        a[iTo][jTo] = temp;
    }

    private boolean zeroInFirstTwo() {
        for (int j = 0; j < 2; j++) {
            if (mBlocks[0][j] == 0) return true;
        }
        return false;
    }

    public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;

        Board that = (Board) y;

        if (this.dimension() != that.dimension()) return false;

        return toString().equals(that.toString());
    }

    public Iterable<Board> neighbors() {
        ArrayList<Board> neighbors = new ArrayList<Board>();

        int iZero = 0;
        int jZero = 0;
        boolean flag = false;
        outherloop:
        for (int i = 0; i < mN; i++) {
            for (int j = 0; j < mN; j++) {
                if (mBlocks[i][j] == 0) {
                    flag = true;
                    iZero = i;
                    jZero = j;
                    break outherloop;
                }
            }
        }

        assert flag;

        addNeighbor(iZero, jZero, iZero + 1, jZero, neighbors);
        addNeighbor(iZero, jZero, iZero, jZero + 1, neighbors);
        addNeighbor(iZero, jZero, iZero - 1, jZero, neighbors);
        addNeighbor(iZero, jZero, iZero, jZero - 1, neighbors);

        return neighbors;
    }

    private void addNeighbor(int iFrom, int jFrom, int iTo, int jTo, ArrayList<Board> neighbors) {
        if ((iTo < 0) || (jTo < 0) || (iTo >= mN) || (jTo >= mN)) return;
        int[][] neighborBlocks = copy2dArray(mBlocks);
        swap(iFrom, jFrom, iTo, jTo, neighborBlocks);
        neighbors.add(new Board(neighborBlocks));
    }


    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(mN + "\n");
        for (int i = 0; i < mN; i++) {
            for (int j = 0; j < mN; j++) {
                s.append(String.format("%2d ", mBlocks[i][j]));
            }
            s.append("\n");
        }
    return s.toString();
    }


    public static void main(String[] args) {
        System.out.println("Olá mundo!");
/*
        int[][] blocks = {
                           {8, 1, 3},
                           {4, 0, 2},
                           {7, 6, 5}
        };*/
        int[][] blocks = {
                           {1, 2},
                           {0, 3}
        };
        Board b = new Board(blocks);
        System.out.println(b.toString());

        for (Board neighbor: b.neighbors()) {
            System.out.println(neighbor.toString());
        }
    }

}